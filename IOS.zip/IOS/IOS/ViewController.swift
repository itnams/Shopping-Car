//
//  ViewController.swift
//  IOS
//
//  Created by Nam Nguyen on 7/23/20.
//  Copyright © 2020 Nam Nguyen. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UITableViewDataSource,UITableViewDelegate {
    var btnHome:UIButton = UIButton()
    var btnlogin:UIButton = UIButton()
    var btnCart:UIButton = UIButton()
    var btnMenu:UIButton = UIButton()
    
    func setbtnMenu() {
        btnMenu = UIButton(frame: CGRect(x: 325, y: 10, width: 40, height: 40))
             navigationController?.navigationBar.addSubview(btnMenu)
        btnMenu.setBackgroundImage(UIImage(named: "menu"), for: .normal)
        btnMenu.addTarget(self, action: #selector(ViewController.showMenu), for: .touchUpInside)
    }
     func setbtnCart() {
           btnCart = UIButton(frame: CGRect(x: 235, y: 10, width: 40, height: 40))
                navigationController?.navigationBar.addSubview(btnCart)
           btnCart.setBackgroundImage(UIImage(named: "cart"), for: .normal)
           btnCart.addTarget(self, action: #selector(ViewController.showMenu), for: .touchUpInside)
       }
    func setbtnlogin() {
        btnlogin = UIButton(frame: CGRect(x: 100, y: 10, width: 40, height: 40))
             navigationController?.navigationBar.addSubview(btnlogin)
        btnlogin.setBackgroundImage(UIImage(named: "login"), for: .normal)
        btnlogin.addTarget(self, action: #selector(ViewController.showMenu), for: .touchUpInside)
    }
    func setButtonHome(){//Khoi tao navagition
             btnHome = UIButton(frame: CGRect(x: 10, y: 10, width: 40, height: 40))
        btnHome.setBackgroundImage(UIImage(named: "Home"), for: .normal)
             navigationController?.navigationBar.addSubview(btnHome)
        btnHome.addTarget(self, action: #selector(ViewController.showMenu), for: .touchUpInside)
         }
    @objc func showMenu()  {
        print("Menu")
        
    }
    @IBOutlet weak var homeView: UITableView!
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrCar[section].count // so xe cua hang do
    }
    func numberOfSections(in tableView: UITableView) -> Int {
        return arrTheFirm.count //so hang xe
    }
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return arrTheFirm[0]
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell:imageCarTableViewCell = tableView.dequeueReusableCell(withIdentifier: "Cell") as! imageCarTableViewCell
        cell.tblTitle.text = arrCar[indexPath.section][indexPath.row]
        cell.imgView.image = UIImage(named: arrCarImage[indexPath.section][indexPath.row])
        return cell
    }
    let arrCar:Array<Array<String>> = [["Vinfast Lux A2.0","Vinfast Lux SA2.0","Vinfast Lux V8"],["Kia Cerato (K3)","Kia Optima (K5)","Kia Quoris (K9)","Kia Rondo","Kia Seltos"],["ROLLS ROYCE PHANTOM","ROLLS ROYCE PHANTOM COUPE/DROPHEAD COUPE"],["MG ZS","MG3"]]// ten xe
    let arrCarImage:Array<Array<String>> = [["vinfast","vinfast","vinfast"],["kia","kia","kia","kia","kia"],["logorollsroyce","logorollsroyce"],["mg","mg"]]//anh cua xe
    let arrTheFirm:Array<String> = ["Vinfast","Kia","ROLLS ROYCE","MG"]// Hang xe
  
    override func viewDidLoad() {
        super.viewDidLoad()
        setButtonHome()
        setbtnlogin()
        setbtnCart()
        setbtnMenu()
        homeView.dataSource = self
        // Do any additional setup after loading the view.
    }
}
